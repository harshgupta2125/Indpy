# The '.' means "look inside the current folder"
from .validators import is_mobile, is_pan, is_gstin

# This list defines what happens if someone types: from indpy import *
__all__ = ['is_mobile', 'is_pan', 'is_gstin']