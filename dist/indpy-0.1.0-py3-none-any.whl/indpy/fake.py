import random
import string

def pan():
    """Generates a random valid PAN card number."""
    # 1. Generate 3 random letters
    chars = ''.join(random.choices(string.ascii_uppercase, k=3))
    # 2. Add 'P' (for individual) and 1 random letter
    chars += 'P' + random.choice(string.ascii_uppercase)
    # 3. Add 4 random digits
    digits = ''.join(random.choices(string.digits, k=4))
    # 4. Add 1 random letter
    last = random.choice(string.ascii_uppercase)
    
    return f"{chars}{digits}{last}"

def mobile():
    """Generates a random valid Indian mobile number."""
    start = random.choice(['6', '7', '8', '9'])
    rest = ''.join(random.choices(string.digits, k=9))
    return f"{start}{rest}"