import re

def is_mobile(number: str) -> bool:
    """
    Validates Indian Mobile Number.
    Accepts: '9876543210', '+919876543210', '+91 9876543210'
    """
    # Clean the number: Remove spaces, dashes, and +91
    clean_num = str(number).replace(" ", "").replace("-", "").replace("+91", "")
    
    # Check if it is exactly 10 digits and starts with 6, 7, 8, or 9
    pattern = r"^[6-9]\d{9}$"
    return bool(re.match(pattern, clean_num))

def is_pan(pan: str) -> bool:
    """
    Validates Indian PAN Card format.
    Format: 5 Letters, 4 Digits, 1 Letter (e.g., ABCDE1234F)
    """
    pattern = r"^[A-Z]{5}[0-9]{4}[A-Z]{1}$"
    return bool(re.match(pattern, pan.upper()))

def is_gstin(gstin: str) -> bool:
    """
    Validates GSTIN using Checksum Algorithm.
    Format: 22AAAAA0000A1Z5
    """
    gstin = gstin.upper().strip()
    
    # Step 1: Basic Regex Check (15 chars total)
    # 2 digits + 5 letters + 4 digits + 1 letter + 1 digit + 'Z' + 1 char
    if not re.match(r"^\d{2}[A-Z]{5}\d{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$", gstin):
        return False

    # Step 2: The Checksum Math (Modulo 36)
    # This ensures the number is mathematically valid
    chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    
    total = 0
    factor = 1 # We multiply by 1, then 2, then 1...

    # Loop through first 14 characters
    for i in range(14):
        code_point = chars.find(gstin[i]) # Get value (A=10, B=11...)
        
        product = factor * code_point
        
        # Add quotient and remainder to total
        digit = (product // 36) + (product % 36)
        total += digit
        
        # Toggle factor (if 1 make 2, if 2 make 1)
        factor = 2 if factor == 1 else 1
        
    # Calculate what the last digit SHOULD be
    check_val = (36 - (total % 36)) % 36
    calculated_char = chars[check_val]
    
    # Compare with actual last digit
    return gstin[14] == calculated_char

def is_ifsc(code: str) -> bool:
    """
    Validates Indian Financial System Code (IFSC).
    Format: 4 Letters (Bank Code) + 0 + 6 Alphanumeric (Branch Code).
    Example: SBIN0001234
    """
    pattern = r"^[A-Z]{4}0[A-Z0-9]{6}$"
    return bool(re.match(pattern, code.upper()))

def is_upi(upi_id: str) -> bool:
    """
    Validates Unified Payments Interface (UPI) ID.
    Example: name@bank, 9876543210@ybl
    """
    # Pattern: characters/numbers -> @ -> characters
    pattern = r"^[\w\.\-]+@[\w\.\-]+$" 
    return bool(re.match(pattern, upi_id))

def is_vehicle_num(number: str) -> bool:
    """
    Validates Indian Vehicle Registration Number.
    Standard Format: XX 00 XX 0000 (State, District, Series, Number)
    Example: DL 01 CA 1234, UP16Z0000
    """
    clean_num = number.replace(" ", "").upper()
    
    # Regex: 
    # ^[A-Z]{2} : Start with 2 chars (State like DL, MH)
    # [0-9]{1,2}: 1 or 2 digits (District code)
    # [A-Z]{0,3}: 0 to 3 letters (Series like C, CA, CAA)
    # [0-9]{4}$ : End with 4 digits
    pattern = r"^[A-Z]{2}[0-9]{1,2}[A-Z]{0,3}[0-9]{4}$"
    
    return bool(re.match(pattern, clean_num))