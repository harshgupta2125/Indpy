__version__ = "0.1.0"

# Import validators
from .validators import is_mobile, is_pan, is_gstin, is_ifsc, is_upi, is_vehicle_num

# Import the fake module as a submodule
from . import fake

__all__ = [
    'is_mobile', 'is_pan', 'is_gstin', 'is_ifsc', 'is_upi', 'is_vehicle_num', 
    'fake'
]